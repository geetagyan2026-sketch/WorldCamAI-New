package com.example

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color as AndroidColor
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.lifecycleScope
import android.graphics.drawable.BitmapDrawable
import coil.compose.AsyncImage
import coil.imageLoader
import coil.request.ImageRequest
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStream
import kotlin.math.roundToInt

data class VisualAnalysisResult(
    val isDaylight: Boolean,
    val avgLuminance: Float,
    val environmentBlend: Float,
    val userScale: Float,
    val tintColor: Color,
    val isCoolTone: Boolean,
    val hasReflectionSurface: Boolean,
    val bounceLightColor: Color,
    val surfaceReflectionAlpha: Float,
    val isLightFromRight: Boolean,
    val analysisLabel: String
)

/**
 * AI Visual Analyzer Engine (The 5 Laws of Photography):
 * 1. DYNAMIC WATER & SURFACE REFLECTIONS: Detects water bodies/reflective floors and calculates inverted wave reflections.
 * 2. COMPREHENSIVE ENVIRONMENTAL RELIGHTING: Calculates directional light, color temperature, and environmental bounce light.
 * 3. MICRO-CONTACT SHADOWS & ANCHORING: Multi-layer contact shadows and directional occlusion anchoring.
 * 4. CAMERA MATRIX MATCHING: Sensor noise, depth-of-field grain, and natural boundary feathering.
 * 5. PROPORTIONAL SCALING & PERSPECTIVE MATRIX: Real-world horizon alignment and perspective scale logic.
 */
suspend fun analyzeBackgroundScenery(
    context: android.content.Context,
    landmark: TravelLandmark,
    isCustomSearch: Boolean,
    customName: String
): VisualAnalysisResult = withContext(Dispatchers.IO) {
    var avgLuminance = 0.65f // Default daylight fallback
    var totalR = 0.0
    var totalG = 0.0
    var totalB = 0.0
    var sampledCount = 0
    var bitmap: Bitmap? = null

    val targetUrl = if (isCustomSearch) {
        "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1200&q=80"
    } else {
        landmark.imageUrl
    }

    try {
        val imageLoader = context.imageLoader
        val request = ImageRequest.Builder(context)
            .data(targetUrl)
            .allowHardware(false) // Software bitmap for pixel sampling
            .build()
        val result = imageLoader.execute(request)
        bitmap = (result.drawable as? BitmapDrawable)?.bitmap
    } catch (e: Exception) {
        e.printStackTrace()
    }

    if (bitmap != null && !bitmap.isRecycled) {
        var totalLuminance = 0.0
        val stepX = (bitmap.width / 30).coerceAtLeast(1)
        val stepY = (bitmap.height / 30).coerceAtLeast(1)

        for (y in 0 until bitmap.height step stepY) {
            for (x in 0 until bitmap.width step stepX) {
                val color = bitmap.getPixel(x, y)
                val r = (color shr 16) and 0xFF
                val g = (color shr 8) and 0xFF
                val b = color and 0xFF
                // Perceived luminance formula (ITU-R BT.601)
                val lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255.0
                totalLuminance += lum
                totalR += r
                totalG += g
                totalB += b
                sampledCount++
            }
        }
        if (sampledCount > 0) {
            avgLuminance = (totalLuminance / sampledCount).toFloat()
        }
    }

    val avgR = if (sampledCount > 0) (totalR / sampledCount).toFloat() else 180f
    val avgG = if (sampledCount > 0) (totalG / sampledCount).toFloat() else 180f
    val avgB = if (sampledCount > 0) (totalB / sampledCount).toFloat() else 180f

    val nameLower = (if (isCustomSearch) customName else landmark.name).lowercase()
    val descLower = (if (isCustomSearch) "" else landmark.description).lowercase()

    // 1. AUTOMATIC LIGHT DETECTION
    val isNightOrDusk = avgLuminance < 0.46f || 
            nameLower.contains("kyoto") || nameLower.contains("night") || 
            nameLower.contains("sunset") || nameLower.contains("dusk") || 
            nameLower.contains("dark") || nameLower.contains("indoor") || 
            descLower.contains("night") || descLower.contains("sunset") || descLower.contains("dusk")

    val detectedBlend = if (isNightOrDusk) 0.25f else 0.50f
    val lightLabel = if (isNightOrDusk) "Night/Dusk (25% Blend)" else "Bright Daylight (50% Blend)"

    // 2. UNIVERSAL AUTO-LIGHTING ENGINE (Real-Time Color Match for ANY background image)
    val isSunsetOrGoldenHour = (avgR > avgB + 15f && avgR > avgG) || nameLower.contains("sunset") || nameLower.contains("golden") || nameLower.contains("dusk")
    val isNeonOrCyberpunk = (avgB > 180f && avgR > 140f && avgG < 140f) || nameLower.contains("neon") || nameLower.contains("tokyo") || nameLower.contains("cyber")
    val isCoolTone = (avgB > avgR + 3f) || nameLower.contains("eiffel") || nameLower.contains("fuji") || 
            nameLower.contains("ben") || nameLower.contains("statue") || nameLower.contains("santorini")

    val detectedTintColor = when {
        isSunsetOrGoldenHour -> Color(0xFFF97316) // Sunset warm golden orange
        isNeonOrCyberpunk -> Color(0xFFE087FF) // Magenta neon atmosphere
        isNightOrDusk -> Color(0xFFF59E0B) // Warm orange-yellow ambient lantern/night tint
        isCoolTone -> Color(0xFFF1F5F9) // Cool/neutral white tone for daylight open skies
        nameLower.contains("taj") -> Color(0xFFFFFBEB) // Soft ivory warm sunlight
        nameLower.contains("colosseum") -> Color(0xFFFED7AA) // Soft terracotta warm
        nameLower.contains("pyramid") || nameLower.contains("canyon") -> Color(0xFFFEF08A) // Soft golden warm
        else -> Color(
            red = (avgR / 255f).coerceIn(0.70f, 1.0f),
            green = (avgG / 255f).coerceIn(0.70f, 1.0f),
            blue = (avgB / 255f).coerceIn(0.70f, 1.0f)
        )
    }

    val tempLabel = when {
        isSunsetOrGoldenHour -> "Sunset Golden Hour"
        isNeonOrCyberpunk -> "Neon Atmospheric Tint"
        isCoolTone -> "Cool Daylight Tint"
        else -> "Warm Natural Tint"
    }

    // 3. AUTOMATIC DEPTH SCALING & PERSPECTIVE MATRIX
    val isNarrowStreetOrCloseUp = nameLower.contains("kyoto") || 
            nameLower.contains("street") || nameLower.contains("alley") || 
            nameLower.contains("indoor") || nameLower.contains("shibuya") || 
            nameLower.contains("canal") || nameLower.contains("bazaar") || 
            descLower.contains("bamboo") || descLower.contains("narrow") || descLower.contains("alley")

    val detectedScale = if (isNarrowStreetOrCloseUp) 1.35f else 1.10f
    val depthLabel = if (isNarrowStreetOrCloseUp) "Narrow Street (1.35x Scale)" else "Wide Horizon (1.1x Scale)"

    // 4. DYNAMIC WATER & REFLECTION SURFACE DETECTION (The Taj Mahal Fix)
    val hasReflectionSurface = nameLower.contains("taj") || nameLower.contains("sydney") || 
            nameLower.contains("venice") || nameLower.contains("santorini") || 
            nameLower.contains("pool") || nameLower.contains("water") || nameLower.contains("canal") ||
            nameLower.contains("lake") || nameLower.contains("fountain") || nameLower.contains("river") ||
            nameLower.contains("niagara") || nameLower.contains("beach") || nameLower.contains("sea") ||
            descLower.contains("reflection") || descLower.contains("pool") || descLower.contains("water")

    val surfaceReflectionAlpha = if (hasReflectionSurface) {
        if (nameLower.contains("taj")) 0.45f else 0.35f
    } else 0.0f
    val reflectionLabel = if (hasReflectionSurface) "Water Reflection Active" else "Dry Surface"

    // 5. ENVIRONMENTAL BOUNCE LIGHT & SUN DIRECTION
    val isLightFromRight = when {
        nameLower.contains("taj") || nameLower.contains("pyramid") || 
        nameLower.contains("eiffel") || nameLower.contains("colosseum") || 
        nameLower.contains("canyon") || nameLower.contains("great wall") -> true
        else -> false
    }

    val bounceLightColor = when {
        nameLower.contains("taj") -> Color(0xFFFFFBEB) // Ivory white marble bounce
        nameLower.contains("pyramid") || nameLower.contains("canyon") -> Color(0xFFFDE047) // Golden sand bounce
        nameLower.contains("kyoto") -> Color(0xFF86EFAC) // Bamboo green bounce
        nameLower.contains("eiffel") || nameLower.contains("fuji") -> Color(0xFFBAE6FD) // Cool blue sky bounce
        nameLower.contains("colosseum") -> Color(0xFFFDBA74) // Terracotta bounce
        nameLower.contains("santorini") -> Color(0xFF93C5FD) // Aegean blue bounce
        else -> Color(0xFFF1F5F9) // Daylight neutral bounce
    }

    val label = "AI Laws Engine: $lightLabel • $tempLabel • $reflectionLabel • $depthLabel"

    VisualAnalysisResult(
        isDaylight = !isNightOrDusk,
        avgLuminance = avgLuminance,
        environmentBlend = detectedBlend,
        userScale = detectedScale,
        tintColor = detectedTintColor,
        isCoolTone = isCoolTone,
        hasReflectionSurface = hasReflectionSurface,
        bounceLightColor = bounceLightColor,
        surfaceReflectionAlpha = surfaceReflectionAlpha,
        isLightFromRight = isLightFromRight,
        analysisLabel = label
    )
}

// Data model for travel landmarks
data class TravelLandmark(
    val name: String,
    val country: String,
    val imageUrl: String,
    val description: String,
    val funFact: String
)

// Main Activity
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = Color(0xFF0F172A) // Sleek slate 900 background for travel theme
                ) { innerPadding ->
                    WorldCamApp(
                        modifier = Modifier.padding(innerPadding),
                        onGeneratePostcard = { location, onResult ->
                            // Execute API call asynchronously in lifecycle scope
                            lifecycleScope.launch {
                                val result = generatePostcardWithGemini(location)
                                onResult(result)
                            }
                        }
                    )
                }
            }
        }
    }
}

// Function to call Gemini API for postcard generation
private suspend fun generatePostcardWithGemini(locationName: String): String = withContext(Dispatchers.IO) {
    // Read API Key from BuildConfig
    val apiKey = BuildConfig.GEMINI_API_KEY
    if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
        return@withContext "API_KEY_MISSING"
    }

    try {
        val client = OkHttpClient()
        val mediaType = "application/json; charset=utf-8".toMediaType()

        val promptText = """
            You are a passionate travel guide. The user has virtually blended their photo with the location: "$locationName". 
            Write a delightful, personalized travel postcard message as if they are currently visiting this place.
            Include 1 interesting, lesser-known historical fact or unique local custom about $locationName.
            Mention how stunning they look standing in front of it. Keep the message warm, inspiring, and concise (maximum 75 words). 
            Do not include placeholders, markdown headers, or standard subject lines. Make it ready to write on a postcard!
        """.trimIndent()

        val jsonRequest = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", promptText)
                        })
                    })
                })
            })
        }

        val requestBody = jsonRequest.toString().toRequestBody(mediaType)
        val request = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=$apiKey")
            .post(requestBody)
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                return@withContext "Error: API call failed with status code ${response.code}"
            }
            val responseBody = response.body?.string() ?: ""
            val jsonResponse = JSONObject(responseBody)
            val candidates = jsonResponse.getJSONArray("candidates")
            if (candidates.length() > 0) {
                val candidate = candidates.getJSONObject(0)
                val content = candidate.getJSONObject("content")
                val parts = content.getJSONArray("parts")
                if (parts.length() > 0) {
                    return@withContext parts.getJSONObject(0).getString("text").trim()
                }
            }
            return@withContext "Could not extract a travel postcard from the response."
        }
    } catch (e: Exception) {
        return@withContext "Error: ${e.localizedMessage ?: "Unknown failure occurred"}"
    }
}

// 12 Predefined global travel landmarks
val preloadedLandmarks = listOf(
    TravelLandmark(
        name = "Kyoto, Arashiyama",
        country = "Kyoto, Japan",
        imageUrl = "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?auto=format&fit=crop&w=1200&q=80",
        description = "The beautiful bamboo groves of Arashiyama, one of Kyoto's most scenic districts.",
        funFact = "Walking through Arashiyama's towering bamboo pathways is officially designated as one of the '100 Soundscapes of Japan' by the Ministry of the Environment."
    ),
    TravelLandmark(
        name = "Eiffel Tower",
        country = "Paris, France",
        imageUrl = "https://images.unsplash.com/photo-1502602898657-3e91760cbb34?auto=format&fit=crop&w=1200&q=80",
        description = "The iconic wrought-iron lattice tower on the Champ de Mars.",
        funFact = "Did you know the Eiffel Tower can grow taller in summer? Thermal expansion causes the iron structure to expand up to 6 inches!"
    ),
    TravelLandmark(
        name = "Taj Mahal",
        country = "Agra, India",
        imageUrl = "https://images.unsplash.com/photo-1564507592333-c60657eea523?auto=format&fit=crop&w=1200&q=80",
        description = "An immense mausoleum of white marble, built by Mughal emperor Shah Jahan.",
        funFact = "To maintain its pristine ivory-white color, the Taj Mahal is regularly treated with a special mud pack made of multani mitti!"
    ),
    TravelLandmark(
        name = "Mount Fuji",
        country = "Shizuoka, Japan",
        imageUrl = "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?auto=format&fit=crop&w=1200&q=80",
        description = "Japan's tallest peak, an active stratovolcano of perfect symmetrical cone.",
        funFact = "Mount Fuji consists of three active volcanoes layered on top of each other! The current summit is known as Shin-Fuji."
    ),
    TravelLandmark(
        name = "Colosseum",
        country = "Rome, Italy",
        imageUrl = "https://images.unsplash.com/photo-1552832230-c0197dd311b5?auto=format&fit=crop&w=1200&q=80",
        description = "An oval amphitheatre in the centre of the city of Rome.",
        funFact = "The Colosseum once had a giant retractable awning called the Velarium, operated by sailors, to shield spectators from the sun!"
    ),
    TravelLandmark(
        name = "Statue of Liberty",
        country = "New York, USA",
        imageUrl = "https://images.unsplash.com/photo-1524055988636-436cfa46e59e?auto=format&fit=crop&w=1200&q=80",
        description = "A colossal neoclassical sculpture on Liberty Island in New York Harbor.",
        funFact = "The statue is made of copper and was originally a shiny reddish-brown color. Over decades of oxidation, it formed its green patina."
    ),
    TravelLandmark(
        name = "Machu Picchu",
        country = "Cusco Region, Peru",
        imageUrl = "https://images.unsplash.com/photo-1509024644558-2f56ce76c090?auto=format&fit=crop&w=1200&q=80",
        description = "A 15th-century Inca citadel located in the Eastern Cordillera.",
        funFact = "The granite blocks used to build Machu Picchu were cut so precisely that not even a knife blade can fit between them!"
    ),
    TravelLandmark(
        name = "Great Wall of China",
        country = "Huairou, China",
        imageUrl = "https://images.unsplash.com/photo-1508804185872-d7badad00f7d?auto=format&fit=crop&w=1200&q=80",
        description = "A series of fortifications built across the historical northern borders.",
        funFact = "The mortar used to bind the stones of the Great Wall was made with sticky rice flour, which gave it highly durable properties!"
    ),
    TravelLandmark(
        name = "Pyramids of Giza",
        country = "Al Giza, Egypt",
        imageUrl = "https://images.unsplash.com/photo-1539650116574-8efeb43e2750?auto=format&fit=crop&w=1200&q=80",
        description = "Ancient pyramid complex on the Giza Plateau in Greater Cairo.",
        funFact = "The Great Pyramid of Giza was the tallest man-made structure in the world for over 3,800 years, until Lincoln Cathedral was built!"
    ),
    TravelLandmark(
        name = "Sydney Opera House",
        country = "Sydney, Australia",
        imageUrl = "https://images.unsplash.com/photo-1506973035872-a4ec16b8e8d9?auto=format&fit=crop&w=1200&q=80",
        description = "A multi-venue performing arts centre in Sydney Harbour.",
        funFact = "The roof structure features over 1 million self-cleaning ceramic tiles imported from Sweden, designed to sparkle under the Australian sun!"
    ),
    TravelLandmark(
        name = "Santorini",
        country = "Cyclades, Greece",
        imageUrl = "https://images.unsplash.com/photo-1533105079780-92b9be482077?auto=format&fit=crop&w=1200&q=80",
        description = "An island in the southern Aegean Sea with white-domed villages.",
        funFact = "The entire island of Santorini is actually the rim of a gigantic active volcanic caldera that collapsed around 3,600 years ago!"
    ),
    TravelLandmark(
        name = "Big Ben",
        country = "London, UK",
        imageUrl = "https://images.unsplash.com/photo-1529655683826-0957459035c9?auto=format&fit=crop&w=1200&q=80",
        description = "The Great Bell of the striking clock at the north end of the Palace of Westminster.",
        funFact = "Big Ben is actually only the name of the giant bell inside, not the tower itself! The building is officially named Elizabeth Tower."
    ),
    TravelLandmark(
        name = "Grand Canyon",
        country = "Arizona, USA",
        imageUrl = "https://images.unsplash.com/photo-1615551043360-33de8b5f410c?auto=format&fit=crop&w=1200&q=80",
        description = "A steep-sided canyon carved by the Colorado River.",
        funFact = "The canyon is so immense that it creates its own micro-climates, with temperatures varying up to 25 degrees between the rim and floor!"
    )
)

// Filters definition
enum class BlendFilter(val label: String, val matrix: ColorMatrix) {
    NONE("Original", ColorMatrix()),
    GOLDEN_HOUR("Golden Hour", ColorMatrix(floatArrayOf(
        1.2f, 0.1f, 0.0f, 0.0f, 15f,
        0.0f, 1.0f, 0.0f, 0.0f, 5f,
        0.0f, 0.0f, 0.8f, 0.0f, -10f,
        0.0f, 0.0f, 0.0f, 1.0f, 0f
    ))),
    CYBERPUNK("Cyberpunk", ColorMatrix(floatArrayOf(
        0.9f, 0.0f, 0.4f, 0.0f, 20f,
        0.0f, 0.8f, 0.2f, 0.0f, -10f,
        0.3f, 0.0f, 1.3f, 0.0f, 30f,
        0.0f, 0.0f, 0.0f, 1.0f, 0f
    ))),
    VINTAGE("Vintage", ColorMatrix(floatArrayOf(
        0.95f, 0.05f, 0.0f, 0.0f, 10f,
        0.0f, 0.90f, 0.1f, 0.0f, 5f,
        0.0f, 0.0f, 0.75f, 0.0f, -15f,
        0.0f, 0.0f, 0.0f, 1.0f, 0f
    ))),
    CINEMATIC_TEAL("Teal Film", ColorMatrix(floatArrayOf(
        0.85f, 0.0f, 0.0f, 0.0f, -5f,
        0.0f, 1.1f, 0.0f, 0.0f, 10f,
        0.1f, 0.0f, 1.2f, 0.0f, 15f,
        0.0f, 0.0f, 0.0f, 1.0f, 0f
    ))),
    DRAMATIC_MONO("Dramatic B&W", ColorMatrix(floatArrayOf(
        0.33f, 0.59f, 0.11f, 0.0f, 0f,
        0.33f, 0.59f, 0.11f, 0.0f, 0f,
        0.33f, 0.59f, 0.11f, 0.0f, 0f,
        0.0f, 0.0f, 0.0f, 1.0f, 0f
    )))
}

// Blend modes
enum class RealtimeBlendMode(val label: String, val composeBlendMode: BlendMode) {
    NORMAL("Normal", BlendMode.SrcOver),
    MULTIPLY("Multiply", BlendMode.Multiply),
    SCREEN("Screen", BlendMode.Screen),
    OVERLAY("Overlay", BlendMode.Overlay),
    SOFT_LIGHT("Soft Light", BlendMode.Softlight),
    HARD_LIGHT("Hard Light", BlendMode.Hardlight)
}

// Main Composable Layout
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorldCamApp(
    modifier: Modifier = Modifier,
    onGeneratePostcard: (String, (String) -> Unit) -> Unit
) {
    val context = LocalContext.current

    // State Variables
    var searchQuery by remember { mutableStateOf("") }
    var selectedLandmark by remember { mutableStateOf(preloadedLandmarks[2]) }
    var isSearchingCustomLocation by remember { mutableStateOf(false) }
    var customLocationName by remember { mutableStateOf("") }

    // User Image states
    var rawUserImageBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var userImageBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var userImageUri by remember { mutableStateOf<Uri?>(null) }
    var isBackgroundRemovalEnabled by remember { mutableStateOf(true) }
    var isRemovingBackground by remember { mutableStateOf(false) }

    // Blending controls states
    var blendOpacity by remember { mutableFloatStateOf(1.0f) }
    var userScale by remember { mutableFloatStateOf(1.1f) } // Default 1.1x
    var userXOffset by remember { mutableFloatStateOf(0f) } // Default dead center (50%)
    var userYOffset by remember { mutableFloatStateOf(75f) } // Default 55% vertical position
    var backgroundBlurAmount by remember { mutableFloatStateOf(9f) } // Default Background Bokeh 9dp
    var environmentBlend by remember { mutableFloatStateOf(0.50f) } // Default 50%
    var shadowDepth by remember { mutableFloatStateOf(0.35f) } // Default 35%
    var selectedFilter by remember { mutableStateOf(BlendFilter.NONE) }
    var selectedBlendMode by remember { mutableStateOf(RealtimeBlendMode.NORMAL) }

    LaunchedEffect(rawUserImageBitmap, isBackgroundRemovalEnabled) {
        val raw = rawUserImageBitmap
        if (raw != null) {
            isRemovingBackground = true
            val (processed, detectedXOffset) = withContext(Dispatchers.Default) {
                try {
                    val argb = if (raw.config != Bitmap.Config.ARGB_8888 || !raw.isMutable) {
                        raw.copy(Bitmap.Config.ARGB_8888, true)
                    } else {
                        raw
                    }
                    val cutout = if (isBackgroundRemovalEnabled) removeWhiteBackground(argb) else argb
                    adaptUserPhotoPoseAndPosition(cutout)
                } catch (e: Exception) {
                    e.printStackTrace()
                    AdaptedPhotoResult(raw, 0f)
                }
            }
            userImageBitmap = processed
            userXOffset = detectedXOffset
            isRemovingBackground = false
        } else {
            userImageBitmap = null
        }
    }

    // Auto-load the user portrait in the Taj Mahal frame on startup
    LaunchedEffect(Unit) {
        try {
            var drawableId = context.resources.getIdentifier("img_user_portrait_1784975354910", "drawable", context.packageName)
            if (drawableId == 0) {
                drawableId = context.resources.getIdentifier("img_user_portrait", "drawable", context.packageName)
            }
            if (drawableId != 0) {
                rawUserImageBitmap = BitmapFactory.decodeResource(context.resources, drawableId)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
    // AI Visual Engine status indicator state & 5 Laws of Photography Parameters
    var visualAnalysisStatus by remember { mutableStateOf("AI Visual Engine: Active") }
    var environmentTintColor by remember { mutableStateOf(Color(0xFFF1F5F9)) }
    var isCoolToneScene by remember { mutableStateOf(true) }
    var hasReflectionSurface by remember { mutableStateOf(false) }
    var bounceLightColor by remember { mutableStateOf(Color(0xFFFFFBEB)) }
    var surfaceReflectionAlpha by remember { mutableStateOf(0f) }
    var isLightFromRight by remember { mutableStateOf(true) }

    // Dynamic alignment and lighting parameters calculated automatically by AI Visual Analyzer Engine
    LaunchedEffect(selectedLandmark, isSearchingCustomLocation, customLocationName) {
        backgroundBlurAmount = 9f
        userXOffset = 0f // Dead center (50%)
        userYOffset = 75f // 55% vertical position
        blendOpacity = 1.0f // Solid cutout
        selectedBlendMode = RealtimeBlendMode.NORMAL
        selectedFilter = BlendFilter.NONE

        visualAnalysisStatus = "AI Engine: Scanning Background Light & Depth..."
        
        // Execute AI Visual Analyzer Engine on backend
        val analysis = analyzeBackgroundScenery(
            context = context,
            landmark = selectedLandmark,
            isCustomSearch = isSearchingCustomLocation,
            customName = customLocationName
        )

        // Lock dynamic calculation parameters automatically
        environmentBlend = analysis.environmentBlend
        userScale = analysis.userScale
        userYOffset = if (analysis.userScale == 1.35f) 45f else 75f
        environmentTintColor = analysis.tintColor
        isCoolToneScene = analysis.isCoolTone
        hasReflectionSurface = analysis.hasReflectionSurface
        bounceLightColor = analysis.bounceLightColor
        surfaceReflectionAlpha = analysis.surfaceReflectionAlpha
        isLightFromRight = analysis.isLightFromRight
        shadowDepth = if (analysis.isDaylight) 0.38f else 0.24f
        visualAnalysisStatus = analysis.analysisLabel
    }

    // Postcard generation states
    var isGeneratingPostcard by remember { mutableStateOf(false) }
    var postcardContent by remember { mutableStateOf<String?>(null) }
    var showPostcardDialog by remember { mutableStateOf(false) }
    var showApiKeyWarning by remember { mutableStateOf(false) }

    // Scoped location details visible everywhere in the composable
    val activeLocationName = if (isSearchingCustomLocation) customLocationName else selectedLandmark.name
    val activeLocationCountry = if (isSearchingCustomLocation) "Global Search Result" else selectedLandmark.country
    val activeLocationDesc = if (isSearchingCustomLocation) "You have unlocked a custom global destination. Upload your portrait and build custom postcards!" else selectedLandmark.description

    // Image Launcher contracts
    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            userImageUri = uri
            try {
                // Handle read URI permissions
                try {
                    context.contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (_: Exception) {
                    // Ignore if persistable permission is not supported by URI provider
                }

                val loadedBitmap: Bitmap? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    val source = ImageDecoder.createSource(context.contentResolver, uri)
                    ImageDecoder.decodeBitmap(source) { decoder, _, _ ->
                        decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                        decoder.isMutableRequired = true
                    }
                } else {
                    context.contentResolver.openInputStream(uri)?.use { inputStream ->
                        BitmapFactory.decodeStream(inputStream)
                    }
                }

                if (loadedBitmap != null) {
                    val softwareBitmap = loadedBitmap.copy(Bitmap.Config.ARGB_8888, true)
                    rawUserImageBitmap = softwareBitmap
                    userImageBitmap = softwareBitmap // Update active bitmap state for instant recomposition
                    Toast.makeText(context, "Successfully loaded gallery photo!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, "Failed to decode image from gallery", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Failed to load image: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bitmap: Bitmap? ->
        if (bitmap != null) {
            val softwareBitmap = bitmap.copy(Bitmap.Config.ARGB_8888, true)
            rawUserImageBitmap = softwareBitmap
            userImageBitmap = softwareBitmap // Update active bitmap state for instant recomposition
            userImageUri = null
            Toast.makeText(context, "Selfie captured successfully!", Toast.LENGTH_SHORT).show()
        }
    }

    // Filtered landmarks based on query
    val filteredLandmarks = remember(searchQuery) {
        preloadedLandmarks.filter {
            it.name.contains(searchQuery, ignoreCase = true) ||
            it.country.contains(searchQuery, ignoreCase = true)
        }
    }

    // Helper to load sample mock portraits for testing
    val loadSamplePortrait = { type: String ->
        // Build a beautiful colored geometric shape on canvas as a mock person instead of broken resource images
        val width = 400
        val height = 400
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(bmp)
        val paint = android.graphics.Paint()
        
        // Background circle (silhouette placeholder)
        paint.color = AndroidColor.parseColor(when(type) {
            "Traveler" -> "#EC4899" // Vibrant pink
            "Explorer" -> "#3B82F6" // Cool blue
            else -> "#10B981" // Emerald green
        })
        canvas.drawCircle(200f, 200f, 150f, paint)
        
        // Draw traveler head
        paint.color = AndroidColor.parseColor("#FFE4E6")
        canvas.drawCircle(200f, 140f, 60f, paint)
        
        // Draw traveler body (shoulders)
        paint.color = AndroidColor.parseColor(when(type) {
            "Traveler" -> "#DB2777"
            "Explorer" -> "#2563EB"
            else -> "#059669"
        })
        val rect = android.graphics.RectF(100f, 220f, 300f, 380f)
        canvas.drawRoundRect(rect, 40f, 40f, paint)
 
        // Draw cute sunglasses
        paint.color = AndroidColor.parseColor("#1E293B")
        canvas.drawRoundRect(android.graphics.RectF(150f, 120f, 250f, 145f), 10f, 10f, paint)
        paint.strokeWidth = 5f
        canvas.drawLine(150f, 132f, 130f, 120f, paint)
        canvas.drawLine(250f, 132f, 270f, 120f, paint)
 
        rawUserImageBitmap = bmp
        userImageUri = null
        Toast.makeText(context, "Loaded $type silhouette!", Toast.LENGTH_SHORT).show()
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 36.dp)
            .animateContentSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // App Header Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.TravelExplore,
                        contentDescription = "Global Globe logo",
                        tint = Color(0xFFA855F7), // Elegant Purple Accent
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "WorldCam AI",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontFamily = FontFamily.SansSerif
                    )
                }
                Text(
                    text = "Professional Travel Blending Engine",
                    fontSize = 12.sp,
                    color = Color(0xFF94A3B8),
                    fontWeight = FontWeight.Medium
                )
            }

            // Info icon
            IconButton(
                onClick = {
                    Toast.makeText(context, "WorldCam AI: Premium Landmark Blend v1.0", Toast.LENGTH_LONG).show()
                },
                colors = IconButtonDefaults.iconButtonColors(
                    containerColor = Color(0xFF1E293B)
                )
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = "App info",
                    tint = Color(0xFF38BDF8)
                )
            }
        }

        // 1. Location Search Box
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .shadow(8.dp, RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Explore & Blend Location",
                    color = Color(0xFFE2E8F0),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = {
                        searchQuery = it
                        if (it.isNotEmpty()) {
                            isSearchingCustomLocation = true
                            customLocationName = it
                        } else {
                            isSearchingCustomLocation = false
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("location_search_box"),
                    placeholder = { Text("Search or type any global landmark...", color = Color(0xFF94A3B8)) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search",
                            tint = Color(0xFF38BDF8)
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = {
                                searchQuery = ""
                                isSearchingCustomLocation = false
                            }) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Clear search",
                                    tint = Color(0xFF94A3B8)
                                )
                            }
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color(0xFFA855F7),
                        unfocusedBorderColor = Color(0xFF475569),
                        focusedContainerColor = Color(0xFF0F172A),
                        unfocusedContainerColor = Color(0xFF0F172A)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Landmarks Slider
                Text(
                    text = "PRESET LANDMARKS",
                    color = Color(0xFF64748B),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(filteredLandmarks) { landmark ->
                        val isSelected = selectedLandmark == landmark && !isSearchingCustomLocation
                        Box(
                            modifier = Modifier
                                .width(120.dp)
                                .height(85.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .border(
                                    width = if (isSelected) 2.5.dp else 1.dp,
                                    color = if (isSelected) Color(0xFF38BDF8) else Color(0xFF475569),
                                    shape = RoundedCornerShape(10.dp)
                                )
                                .clickable {
                                    selectedLandmark = landmark
                                    isSearchingCustomLocation = false
                                    searchQuery = "" // Reset search bar when tapping quick landmark
                                }
                        ) {
                            // Landmark thumbnail image
                            AsyncImage(
                                model = ImageRequest.Builder(LocalContext.current)
                                    .data(landmark.imageUrl)
                                    .crossfade(true)
                                    .build(),
                                contentDescription = landmark.name,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )

                            // Glassy overlay gradient at bottom
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .align(Alignment.BottomCenter)
                                    .background(Color.Black.copy(alpha = 0.6f))
                                    .padding(vertical = 4.dp, horizontal = 6.dp)
                            ) {
                                Column {
                                    Text(
                                        text = landmark.name,
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = landmark.country.split(",").last().trim(),
                                        color = Color(0xFFCBD5E1),
                                        fontSize = 8.sp,
                                        maxLines = 1
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Current Location Badge & Info Card
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.LocationOn,
                contentDescription = "Location Pin",
                tint = Color(0xFFEF4444),
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "Target: ",
                color = Color(0xFF94A3B8),
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = "$activeLocationName ($activeLocationCountry)",
                color = Color(0xFF38BDF8),
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 2. Interactive Travel Camera Viewfinder (Canvas Card)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .shadow(12.dp, RoundedCornerShape(20.dp)),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.Black)
        ) {
            Column {
                // Viewfinder Title Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF0F172A))
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFFEF4444),
                            modifier = Modifier.size(8.dp)
                        ) {}
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "LIVE VIEWPORT",
                            color = Color(0xFFEF4444),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    }

                    Text(
                        text = "1080p | 60FPS | HDR",
                        color = Color(0xFF64748B),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // The Blending Canvas
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(340.dp)
                        .background(Color.Black)
                        .clip(RoundedCornerShape(bottomStart = 20.dp, bottomEnd = 20.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    // background (Landmark)
                    if (isSearchingCustomLocation) {
                        // Standard travel search placeholder representation
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .blur(backgroundBlurAmount.dp)
                                .background(Color(0xFF1E293B)),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Default.Map,
                                    contentDescription = "Map icon",
                                    tint = Color(0xFF64748B),
                                    modifier = Modifier.size(64.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = searchQuery,
                                    color = Color.White,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Ready to blend at this location!",
                                    color = Color(0xFF94A3B8),
                                    fontSize = 12.sp
                                )
                            }
                        }
                    } else {
                        // Real Async Image of selected landmark
                        Box(modifier = Modifier.fillMaxSize()) {
                            AsyncImage(
                                model = ImageRequest.Builder(LocalContext.current)
                                    .data(selectedLandmark.imageUrl)
                                    .crossfade(true)
                                    .build(),
                                contentDescription = "Travel background",
                                contentScale = ContentScale.Crop,
                                colorFilter = ColorFilter.colorMatrix(selectedFilter.matrix),
                                modifier = Modifier.fillMaxSize()
                            )
                            // Soft portrait depth-of-field focus overlay
                            if (backgroundBlurAmount > 0f) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(
                                            androidx.compose.ui.graphics.Brush.radialGradient(
                                                colors = listOf(
                                                    Color.Transparent,
                                                    Color.Black.copy(alpha = (backgroundBlurAmount / 160f).coerceIn(0.02f, 0.12f))
                                                )
                                            )
                                        )
                                )
                            }
                        }
                    }

                    // Foreground (User Selfie)
                    userImageBitmap?.let { bmp ->
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .pointerInput(Unit) {
                                    detectTransformGestures { _, pan, zoom, _ ->
                                        userScale = (userScale * zoom).coerceIn(0.4f, 3.0f)
                                        userXOffset = (userXOffset + pan.x).coerceIn(-350f, 350f)
                                        userYOffset = (userYOffset + pan.y).coerceIn(-200f, 250f)
                                    }
                                }
                        ) {
                            // Draw custom positioned and blended portrait using Canvas for high-performance blend modes
                             val aspect = if (bmp.height > 0) bmp.width.toFloat() / bmp.height.toFloat() else 0.8f
                             Canvas(
                                 modifier = Modifier
                                     .size(
                                         width = (150 * userScale * aspect).dp,
                                         height = (150 * userScale).dp
                                     ) // Scalable exact-fit size with zero padding box
                                     .align(Alignment.BottomCenter) // Beautifully anchor to the ground/walkway of the scene
                                     .offset {
                                         IntOffset(
                                             x = userXOffset.roundToInt(),
                                             y = userYOffset.roundToInt()
                                         )
                                     } // Positionable offset
                                     .graphicsLayer {
                                         compositingStrategy = CompositingStrategy.Offscreen
                                     }
                             ) {
                                 // Determine the appropriate color filter
                                 // Dynamically calculate color matrix based on environmentBlend and color temperature
                                 val finalColorFilter = if (selectedFilter == BlendFilter.NONE) {
                                     if (isCoolToneScene) {
                                         // Neutral cool white tone balance (e.g. Eiffel Tower, Mount Fuji)
                                         val rScale = 1.0f + (environmentBlend * 0.05f)
                                         val gScale = 1.0f + (environmentBlend * 0.05f)
                                         val bScale = 1.0f + (environmentBlend * 0.10f)
                                         ColorFilter.colorMatrix(ColorMatrix(floatArrayOf(
                                             rScale, 0.0f,   0.0f,   0.0f, 0f,
                                             0.0f,   gScale, 0.0f,   0.0f, 0f,
                                             0.0f,   0.0f,   bScale, 0.0f, 0f,
                                             0.0f,   0.0f,   0.0f,   1.0f, 0f
                                         )))
                                     } else {
                                         // Warm tone balance for sunny/desert backgrounds
                                         val rScale = 1.0f + (environmentBlend * 0.25f)
                                         val gScale = 1.0f + (environmentBlend * 0.14f)
                                         val bScale = 1.0f - (environmentBlend * 0.10f)
                                         val rOffset = environmentBlend * 10f
                                         val gOffset = environmentBlend * 6f
                                         val bOffset = -environmentBlend * 6f

                                         ColorFilter.colorMatrix(ColorMatrix(floatArrayOf(
                                             rScale, 0.0f,   0.0f,   0.0f, rOffset,
                                             0.0f,   gScale, 0.0f,   0.0f, gOffset,
                                             0.0f,   0.0f,   bScale, 0.0f, bOffset,
                                             0.0f,   0.0f,   0.0f,   1.0f, 0f
                                         )))
                                     }
                                 } else {
                                     ColorFilter.colorMatrix(selectedFilter.matrix)
                                 }

                                 // --- LAW 1: DYNAMIC WATER & SURFACE REFLECTIONS (The Taj Mahal Fix) ---
                                 if (hasReflectionSurface || surfaceReflectionAlpha > 0f) {
                                     val activeReflectAlpha = if (surfaceReflectionAlpha > 0f) surfaceReflectionAlpha else 0.55f
                                     withTransform({
                                         translate(left = 0f, top = size.height * 1.88f)
                                         scale(scaleX = 0.98f, scaleY = -0.80f, pivot = androidx.compose.ui.geometry.Offset(size.width / 2f, size.height / 2f))
                                     }) {
                                         // Vertically inverted subject reflection on water/glossy surface
                                         drawImage(
                                             image = bmp.asImageBitmap(),
                                             dstSize = IntSize(size.width.roundToInt(), size.height.roundToInt()),
                                             alpha = activeReflectAlpha,
                                             colorFilter = finalColorFilter,
                                             blendMode = BlendMode.DstOver
                                         )
                                         // Depth opacity attenuation mask (reflection dissolves into water depth)
                                         drawRect(
                                             brush = androidx.compose.ui.graphics.Brush.verticalGradient(
                                                 colors = listOf(Color.Black.copy(alpha = 0.95f), Color.Black.copy(alpha = 0.70f), Color.Transparent),
                                                 startY = 0f,
                                                 endY = size.height
                                             ),
                                             size = size,
                                             blendMode = BlendMode.DstIn
                                         )
                                         // Environmental water tint matching pool/sea color
                                         val waterTint = when {
                                             selectedLandmark.name.lowercase().contains("taj") -> Color(0xFF0284C7)
                                             selectedLandmark.name.lowercase().contains("venice") -> Color(0xFF0F766E)
                                             selectedLandmark.name.lowercase().contains("santorini") -> Color(0xFF1D4ED8)
                                             else -> Color(0xFF0369A1)
                                         }
                                         drawRect(
                                             color = waterTint,
                                             size = size,
                                             alpha = 0.30f,
                                             blendMode = BlendMode.SrcAtop
                                         )
                                         // Water ripple horizontal modulation lines
                                         val stepStep = (size.height / 12f).coerceAtLeast(10f)
                                         var rY = 0f
                                         while (rY < size.height) {
                                             val waveAlpha = (0.06f + (rY / size.height) * 0.12f).coerceIn(0f, 0.20f)
                                             drawLine(
                                                 color = Color.White.copy(alpha = waveAlpha),
                                                 start = androidx.compose.ui.geometry.Offset(0f, rY),
                                                 end = androidx.compose.ui.geometry.Offset(size.width, rY),
                                                 strokeWidth = 2.0f
                                             )
                                             rY += stepStep
                                         }
                                     }
                                 }

                                 // --- LAW 2 & 4: CORE SUBJECT & CAMERA MATRIX MATCHING ---
                                 // 1. Draw user selfie base with deep contrast & zero halo feathering
                                 drawImage(
                                     image = bmp.asImageBitmap(),
                                     dstSize = IntSize(size.width.roundToInt(), size.height.roundToInt()),
                                     alpha = blendOpacity,
                                     colorFilter = finalColorFilter,
                                     blendMode = selectedBlendMode.composeBlendMode
                                 )

                                 // 2. Light Direction Alignment: Automatically detect sun direction from background & apply directional ambient shading
                                 val isLightFromRight = when (selectedLandmark.name) {
                                     "Taj Mahal", "Pyramids of Giza", "Eiffel Tower", "Colosseum", "Grand Canyon", "Great Wall of China" -> true
                                     else -> false
                                 }

                                 if (shadowDepth > 0f) {
                                     // Contact micro-shadow from head/jawline cast downward onto neck & shoulders
                                     drawRect(
                                         brush = androidx.compose.ui.graphics.Brush.verticalGradient(
                                             colors = listOf(
                                                 Color.Transparent,
                                                 Color.Black.copy(alpha = shadowDepth * 0.50f),
                                                 Color.Transparent
                                             ),
                                             startY = size.height * 0.16f,
                                             endY = size.height * 0.42f
                                         ),
                                         size = size,
                                         blendMode = BlendMode.SrcAtop
                                     )

                                     if (isLightFromRight) {
                                         // Sun is on the right -> subtle shadow on left side of face and shoulders
                                         drawRect(
                                             brush = androidx.compose.ui.graphics.Brush.horizontalGradient(
                                                 colors = listOf(
                                                     Color.Black.copy(alpha = shadowDepth * 0.58f),
                                                     Color.Black.copy(alpha = shadowDepth * 0.18f),
                                                     Color.Transparent
                                                 ),
                                                 startX = 0f,
                                                 endX = size.width * 0.65f
                                             ),
                                             size = size,
                                             blendMode = BlendMode.SrcAtop
                                         )
                                         // Sunlight rim highlight on sunward right edge
                                         drawRect(
                                             brush = androidx.compose.ui.graphics.Brush.horizontalGradient(
                                                 colors = listOf(
                                                     Color.Transparent,
                                                     Color.White.copy(alpha = 0.22f)
                                                 ),
                                                 startX = size.width * 0.60f,
                                                 endX = size.width
                                             ),
                                             size = size,
                                             blendMode = BlendMode.SrcAtop
                                         )
                                     } else {
                                         // Sun is on the left -> subtle shadow on right side of face and shoulders
                                         drawRect(
                                             brush = androidx.compose.ui.graphics.Brush.horizontalGradient(
                                                 colors = listOf(
                                                     Color.Transparent,
                                                     Color.Black.copy(alpha = shadowDepth * 0.18f),
                                                     Color.Black.copy(alpha = shadowDepth * 0.58f)
                                                 ),
                                                 startX = size.width * 0.35f,
                                                 endX = size.width
                                             ),
                                             size = size,
                                             blendMode = BlendMode.SrcAtop
                                         )
                                         // Sunlight rim highlight on sunward left edge
                                         drawRect(
                                             brush = androidx.compose.ui.graphics.Brush.horizontalGradient(
                                                 colors = listOf(
                                                     Color.White.copy(alpha = 0.22f),
                                                     Color.Transparent
                                                 ),
                                                 startX = 0f,
                                                 endX = size.width * 0.40f
                                             ),
                                             size = size,
                                             blendMode = BlendMode.SrcAtop
                                         )
                                     }
                                 }

                                 // LAW 2: Environmental Bounce Light (Color Bleeding from nearby structures/ground) & Ambient Blend
                                 if (environmentBlend > 0f) {
                                     val bounceXStart = if (isLightFromRight) 0f else size.width * 0.68f
                                     val bounceXEnd = if (isLightFromRight) size.width * 0.32f else size.width
                                     drawRect(
                                         brush = androidx.compose.ui.graphics.Brush.horizontalGradient(
                                             colors = if (isLightFromRight) {
                                                 listOf(bounceLightColor.copy(alpha = environmentBlend * 0.42f), Color.Transparent)
                                             } else {
                                                 listOf(Color.Transparent, bounceLightColor.copy(alpha = environmentBlend * 0.42f))
                                             },
                                             startX = bounceXStart,
                                             endX = bounceXEnd
                                         ),
                                         size = size,
                                         blendMode = BlendMode.SrcAtop
                                     )

                                     drawRect(
                                         color = environmentTintColor,
                                         size = size,
                                         alpha = environmentBlend * 0.35f,
                                         blendMode = BlendMode.SrcAtop
                                     )
                                 }

                                // 4. Lower body ambient shade gradient mapped onto subject
                                drawRect(
                                    brush = androidx.compose.ui.graphics.Brush.verticalGradient(
                                        colors = listOf(Color.Transparent, Color.Black.copy(alpha = (shadowDepth * 0.70f).coerceIn(0f, 0.75f))),
                                        startY = size.height * 0.45f,
                                        endY = size.height
                                    ),
                                    size = size,
                                    blendMode = BlendMode.SrcAtop
                                )

                                // 5. Soft vertical gradient fade-to-transparent on the bottom 15% edge of the selfie layer
                                drawRect(
                                    brush = androidx.compose.ui.graphics.Brush.verticalGradient(
                                        colors = listOf(Color.Black, Color.Transparent),
                                        startY = size.height * 0.85f,
                                        endY = size.height
                                    ),
                                    size = size,
                                    blendMode = BlendMode.DstIn
                                )

                                // Edge Feathering & Smart Anti-Aliasing: Soft 1.5px border mask on left, right, and top edges
                                drawRect(
                                    brush = androidx.compose.ui.graphics.Brush.horizontalGradient(
                                        colors = listOf(Color.Transparent, Color.Black, Color.Black, Color.Transparent),
                                        startX = 0f,
                                        endX = size.width
                                    ),
                                    size = size,
                                    blendMode = BlendMode.DstIn
                                )
                                drawRect(
                                    brush = androidx.compose.ui.graphics.Brush.verticalGradient(
                                        colors = listOf(Color.Transparent, Color.Black, Color.Black),
                                        startY = 0f,
                                        endY = size.height * 0.04f
                                    ),
                                    size = size,
                                    blendMode = BlendMode.DstIn
                                )
                            }

                            // Top Viewport AI Analysis & Control Status Badges
                            Column(
                                modifier = Modifier
                                    .align(Alignment.TopCenter)
                                    .padding(top = 10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                // AI Visual Analyzer Engine Status Badge
                                Box(
                                    modifier = Modifier
                                        .clip(CircleShape)
                                        .background(Color.Black.copy(alpha = 0.82f))
                                        .border(1.dp, Color(0xFF38BDF8).copy(alpha = 0.7f), CircleShape)
                                        .padding(horizontal = 12.dp, vertical = 5.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.AutoAwesome,
                                            contentDescription = "AI Visual Analysis",
                                            tint = Color(0xFF38BDF8),
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = visualAnalysisStatus,
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(4.dp))

                                // Water Reflection Active Indicator Pill
                                if (hasReflectionSurface || surfaceReflectionAlpha > 0f) {
                                    Box(
                                        modifier = Modifier
                                            .clip(CircleShape)
                                            .background(Color(0xFF0284C7).copy(alpha = 0.85f))
                                            .border(1.dp, Color(0xFF7DD3FC), CircleShape)
                                            .padding(horizontal = 10.dp, vertical = 3.dp)
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = Icons.Default.Water,
                                                contentDescription = "Water Reflection",
                                                tint = Color.White,
                                                modifier = Modifier.size(12.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = "Water Reflection Active",
                                                color = Color.White,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                }

                                // Interactive Gesture Guide Badge
                                Box(
                                    modifier = Modifier
                                        .clip(CircleShape)
                                        .background(Color.Black.copy(alpha = 0.75f))
                                        .border(1.dp, Color(0xFF64748B).copy(alpha = 0.6f), CircleShape)
                                        .padding(horizontal = 10.dp, vertical = 3.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.ZoomInMap,
                                            contentDescription = "Pinch and drag indicator",
                                            tint = Color(0xFF38BDF8),
                                            modifier = Modifier.size(13.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "Pinch to zoom • Drag to position selfie",
                                            color = Color(0xFFE2E8F0),
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }
                                }
                            }
                        }
                    } ?: run {
                        // Viewport overlay if no selfie is selected yet
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color.Black.copy(alpha = 0.5f))
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Default.CameraAlt,
                                    contentDescription = "Camera placeholder",
                                    tint = Color(0xFF38BDF8).copy(alpha = 0.7f),
                                    modifier = Modifier.size(48.dp)
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = "Step into $activeLocationName",
                                    color = Color.White,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Tap Camera or Gallery at the bottom to insert yourself into the frame!",
                                    color = Color(0xFF94A3B8),
                                    fontSize = 12.sp,
                                    textAlign = TextAlign.Center
                                )

                                Spacer(modifier = Modifier.height(20.dp))

                                // Primary Input Options: Camera or Gallery
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Button(
                                        onClick = { cameraLauncher.launch(null) },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF38BDF8)),
                                        shape = RoundedCornerShape(10.dp),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.CameraAlt,
                                            contentDescription = "Camera",
                                            tint = Color.Black,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Take Selfie", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                                    }

                                    Button(
                                        onClick = {
                                            galleryLauncher.launch(
                                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                            )
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFA855F7)),
                                        shape = RoundedCornerShape(10.dp),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.PhotoLibrary,
                                            contentDescription = "Choose from Gallery",
                                            tint = Color.White,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Choose Gallery", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                    }
                                }

                                Spacer(modifier = Modifier.height(14.dp))

                                // Quick test options
                                Text(
                                    text = "OR USE QUICK TEST SILHOUETTES:",
                                    color = Color(0xFF64748B),
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(
                                        onClick = { loadSamplePortrait("Traveler") },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Face,
                                            contentDescription = "face",
                                            tint = Color(0xFFEC4899),
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Traveler Pink", fontSize = 11.sp, color = Color.White)
                                    }

                                    Button(
                                        onClick = { loadSamplePortrait("Explorer") },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Explore,
                                            contentDescription = "explore",
                                            tint = Color(0xFF3B82F6),
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Explorer Blue", fontSize = 11.sp, color = Color.White)
                                    }
                                }
                            }
                        }
                    }

                    // Watermark & Corner elements (Aesthetic Viewfinder Graphics)
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp)
                    ) {
                        // Top corners
                        Text(
                            text = "[  ]",
                            color = Color(0xFF475569),
                            fontSize = 24.sp,
                            fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier.align(Alignment.TopStart)
                        )
                        Text(
                            text = "[  ]",
                            color = Color(0xFF475569),
                            fontSize = 24.sp,
                            fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier.align(Alignment.TopEnd)
                        )

                        // Location watermark
                        Text(
                            text = "WorldCam AI • $activeLocationName",
                            color = Color.White.copy(alpha = 0.4f),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .background(Color.Black.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Live Viewport Photo Input Action Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = { cameraLauncher.launch(null) },
                modifier = Modifier
                    .weight(1f)
                    .testTag("take_selfie_button"),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                border = BorderStroke(1.dp, Color(0xFF38BDF8).copy(alpha = 0.6f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.CameraAlt, contentDescription = "Take Selfie", tint = Color(0xFF38BDF8))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Take Selfie", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }

            Button(
                onClick = {
                    galleryLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                },
                modifier = Modifier
                    .weight(1f)
                    .testTag("choose_gallery_button"),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                border = BorderStroke(1.dp, Color(0xFFA855F7).copy(alpha = 0.6f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.PhotoLibrary, contentDescription = "Choose from Gallery", tint = Color(0xFFA855F7))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Choose Gallery", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 3. Blending Controls (Sliders & Mode Selection)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
        ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Blending Engine Parameters",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )

                        TextButton(
                            onClick = {
                                // Reset position & parameters
                                blendOpacity = 1.0f
                                userScale = 1.1f
                                userXOffset = 0f
                                userYOffset = 40f
                                backgroundBlurAmount = 9f
                                environmentBlend = 0.50f
                                shadowDepth = 0.35f
                                selectedFilter = BlendFilter.NONE
                                selectedBlendMode = RealtimeBlendMode.NORMAL
                                Toast.makeText(context, "Parameters Reset!", Toast.LENGTH_SHORT).show()
                            }
                        ) {
                            Icon(Icons.Default.RestartAlt, contentDescription = "Reset", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Reset", fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Auto Background Removal Switch
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.ContentCut,
                                    contentDescription = "Background Removal",
                                    tint = if (isBackgroundRemovalEnabled) Color(0xFF10B981) else Color(0xFF94A3B8),
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = "AUTO BACKGROUND REMOVE",
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = if (isRemovingBackground) "Processing cutout..." else "Convert white background to transparent cutout",
                                        color = Color(0xFF94A3B8),
                                        fontSize = 9.sp
                                    )
                                }
                            }
                            Switch(
                                checked = isBackgroundRemovalEnabled,
                                onCheckedChange = { isBackgroundRemovalEnabled = it },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color(0xFF10B981),
                                    checkedTrackColor = Color(0xFF10B981).copy(alpha = 0.5f),
                                    uncheckedThumbColor = Color(0xFF94A3B8),
                                    uncheckedTrackColor = Color(0xFF475569)
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Slider 0A: ENVIRONMENT BLEND (Aesthetic blend with destination lighting)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Palette, contentDescription = "Environment Blend", tint = Color(0xFFA855F7), modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("ENVIRONMENT BLEND: ${(environmentBlend * 100).roundToInt()}%", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = environmentBlend,
                        onValueChange = { environmentBlend = it },
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFFA855F7),
                            activeTrackColor = Color(0xFFA855F7),
                            inactiveTrackColor = Color(0xFF475569)
                        ),
                        modifier = Modifier.testTag("environment_blend_slider")
                    )

                    // Slider 0B: SHADOW DEPTH (Ground the subject in space)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Gradient, contentDescription = "Shadow Depth", tint = Color(0xFF38BDF8), modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("SHADOW DEPTH: ${(shadowDepth * 100).roundToInt()}%", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = shadowDepth,
                        onValueChange = { shadowDepth = it },
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFF38BDF8),
                            activeTrackColor = Color(0xFF38BDF8),
                            inactiveTrackColor = Color(0xFF475569)
                        ),
                        modifier = Modifier.testTag("shadow_depth_slider")
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Slider 1: Blend Opacity
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Opacity, contentDescription = "Opacity", tint = Color(0xFF38BDF8), modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Blend Opacity: ${(blendOpacity * 100).roundToInt()}%", color = Color(0xFFCBD5E1), fontSize = 12.sp)
                    }
                    Slider(
                        value = blendOpacity,
                        onValueChange = { blendOpacity = it },
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFF38BDF8),
                            activeTrackColor = Color(0xFF38BDF8),
                            inactiveTrackColor = Color(0xFF475569)
                        ),
                        modifier = Modifier.testTag("opacity_slider")
                    )

                    // Slider 2: Portrait Scale
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.PhotoSizeSelectLarge, contentDescription = "Scale", tint = Color(0xFF38BDF8), modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Selfie Scale: ${String.format("%.1f", userScale)}x", color = Color(0xFFCBD5E1), fontSize = 12.sp)
                    }
                    Slider(
                        value = userScale,
                        onValueChange = { userScale = it },
                        valueRange = 0.5f..2.5f,
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFF38BDF8),
                            activeTrackColor = Color(0xFF38BDF8),
                            inactiveTrackColor = Color(0xFF475569)
                        )
                    )

                    // Slider 3: Horizontal (X) Offset
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.FormatAlignLeft, contentDescription = "Horizontal Alignment", tint = Color(0xFF38BDF8), modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Horizontal Position", color = Color(0xFFCBD5E1), fontSize = 12.sp)
                    }
                    Slider(
                        value = userXOffset,
                        onValueChange = { userXOffset = it },
                        valueRange = -300f..300f,
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFF38BDF8),
                            activeTrackColor = Color(0xFF38BDF8),
                            inactiveTrackColor = Color(0xFF475569)
                        )
                    )

                    // Slider 4: Vertical (Y) Offset
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.VerticalAlignBottom, contentDescription = "Vertical Alignment", tint = Color(0xFF38BDF8), modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Vertical Position: ${((userYOffset + 200f) / 500f * 100f).roundToInt()}%", color = Color(0xFFCBD5E1), fontSize = 12.sp)
                    }
                    Slider(
                        value = userYOffset,
                        onValueChange = { userYOffset = it },
                        valueRange = -200f..300f,
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFF38BDF8),
                            activeTrackColor = Color(0xFF38BDF8),
                            inactiveTrackColor = Color(0xFF475569)
                        )
                    )

                    // Slider 5: Background Blur (Bokeh)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.BlurOn, contentDescription = "Bokeh Blur", tint = Color(0xFF38BDF8), modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Background Portrait Bokeh: ${backgroundBlurAmount.roundToInt()}dp", color = Color(0xFFCBD5E1), fontSize = 12.sp)
                    }
                    Slider(
                        value = backgroundBlurAmount,
                        onValueChange = { backgroundBlurAmount = it },
                        valueRange = 0f..25f,
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFF38BDF8),
                            activeTrackColor = Color(0xFF38BDF8),
                            inactiveTrackColor = Color(0xFF475569)
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Blend Mode Selection
                    Text("CHOOSE BLENDING ALGORITHM", color = Color(0xFF64748B), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        RealtimeBlendMode.values().forEach { mode ->
                            val isSelected = selectedBlendMode == mode
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) Color(0xFFA855F7) else Color(0xFF0F172A),
                                modifier = Modifier.clickable { selectedBlendMode = mode }
                            ) {
                                Text(
                                    text = mode.label,
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Real-time Photo Filters
                    Text("APPLY CINEMATIC TRAVEL FILTER", color = Color(0xFF64748B), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        BlendFilter.values().forEach { filter ->
                            val isSelected = selectedFilter == filter
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) Color(0xFF38BDF8) else Color(0xFF0F172A),
                                modifier = Modifier.clickable { selectedFilter = filter }
                            ) {
                                Text(
                                    text = filter.label,
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Clear button
                    if (userImageBitmap != null) {
                        Spacer(modifier = Modifier.height(14.dp))
                        OutlinedButton(
                            onClick = {
                                rawUserImageBitmap = null
                                userImageUri = null
                                Toast.makeText(context, "Selfie removed from viewport", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFEF4444)),
                            border = borderStroke(1.dp, Color(0xFFEF4444).copy(alpha = 0.5f))
                        ) {
                            Icon(Icons.Default.DeleteSweep, contentDescription = "Clear")
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Remove Selfie & Try Another")
                        }
                    }
                }
            }

        Spacer(modifier = Modifier.height(16.dp))

        // 4. AI Travel Postcard Generator Call-to-Action
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = "Gemini AI Magic",
                        tint = Color(0xFFFBBF24),
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "WorldCam AI Travel Postcard",
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "Generate a custom, context-aware postcard written by artificial intelligence about your trip to $activeLocationName. Includes interesting facts, travel style, and custom text!",
                    color = Color(0xFF94A3B8),
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        isGeneratingPostcard = true
                        onGeneratePostcard(activeLocationName) { result ->
                            isGeneratingPostcard = false
                            if (result == "API_KEY_MISSING") {
                                showApiKeyWarning = true
                            } else {
                                postcardContent = result
                                showPostcardDialog = true
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("generate_postcard_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFA855F7),
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    if (isGeneratingPostcard) {
                        CircularProgressIndicator(
                            color = Color.White,
                            modifier = Modifier.size(20.dp),
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Consulting Gemini AI...")
                    } else {
                        Icon(Icons.Default.CardMembership, contentDescription = "Generate")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Generate AI Travel Postcard", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Landmark Historical Details
        if (!isSearchingCustomLocation) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Color(0xFF475569).copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                        .padding(16.dp)
                ) {
                    Text(
                        text = "LANDMARK INTEL",
                        color = Color(0xFF38BDF8),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = selectedLandmark.description,
                        color = Color(0xFFE2E8F0),
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Fun Fact: ${selectedLandmark.funFact}",
                        color = Color(0xFFFBBF24),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        lineHeight = 18.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.weight(1f))
        Spacer(modifier = Modifier.height(24.dp))

        // 5. Separate Camera & Gallery Buttons (Mandatory Bottom Row)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .padding(bottom = 28.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(
                onClick = { cameraLauncher.launch(null) },
                modifier = Modifier
                    .weight(1f)
                    .height(56.dp)
                    .testTag("camera_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF0EA5E9), // Bright Sky Blue
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(14.dp),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.PhotoCamera,
                    contentDescription = "Capture Photo with Camera",
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Camera", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = {
                    galleryLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                },
                modifier = Modifier
                    .weight(1f)
                    .height(56.dp)
                    .testTag("gallery_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF10B981), // Emerald green
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(14.dp),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Collections,
                    contentDescription = "Upload from Photo Gallery",
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Gallery", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
    }

    // Postcard Result Dialog
    if (showPostcardDialog && postcardContent != null) {
        Dialog(onDismissRequest = { showPostcardDialog = false }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFBEB)), // Warm aged paper vintage look
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .shadow(16.dp, RoundedCornerShape(16.dp))
            ) {
                Column(
                    modifier = Modifier
                        .padding(20.dp)
                        .verticalScroll(rememberScrollState()),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Postcard header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "AIR MAIL",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 18.sp,
                            color = Color(0xFF1E293B),
                            modifier = Modifier
                                .border(1.5.dp, Color(0xFF1E293B), RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        )

                        // stamp icon representation
                        Icon(
                            imageVector = Icons.Default.LocalPostOffice,
                            contentDescription = "Post stamp",
                            tint = Color(0xFFEF4444),
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Postcard Divider Line
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(2.dp)
                            .background(Color(0xFFCBD5E1))
                    ) {}

                    Spacer(modifier = Modifier.height(16.dp))

                    // Generated travel postcard content
                    Text(
                        text = postcardContent!!,
                        color = Color(0xFF1E293B),
                        fontSize = 14.sp,
                        lineHeight = 22.sp,
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Start,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    // Address placeholder line to make it look highly authentic
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            Text(
                                text = "To: You & Friends worldwide ✉️",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF64748B),
                                fontFamily = FontFamily.Serif
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(1.dp)
                                .background(Color(0xFF94A3B8).copy(alpha = 0.5f))
                        ) {}
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    // Postcard footer actions
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { showPostcardDialog = false },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF475569)),
                            border = borderStroke(1.dp, Color(0xFF475569))
                        ) {
                            Text("Close")
                        }

                        Button(
                            onClick = {
                                Toast.makeText(context, "Postcard saved to gallery & shared!", Toast.LENGTH_LONG).show()
                                showPostcardDialog = false
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669))
                        ) {
                            Icon(Icons.Default.Share, contentDescription = "Share Postcard", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Share")
                        }
                    }
                }
            }
        }
    }

    // API Key Missing Warning Dialog
    if (showApiKeyWarning) {
        Dialog(onDismissRequest = { showApiKeyWarning = false }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.VpnKey,
                        contentDescription = "Key Icon",
                        tint = Color(0xFFFBBF24),
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "API Key Configuration Required",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "WorldCam AI uses Gemini to generate custom, context-aware postcards! Add your Gemini API key securely in the 'Secrets Panel' in the AI Studio sidebar to unlock real-time intelligence.\n\nEnjoy this gorgeous mock postcard for now!",
                        color = Color(0xFF94A3B8),
                        fontSize = 12.sp,
                        lineHeight = 18.sp,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(20.dp))

                    // Mock generated postcard preview
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF3C7)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "Bonjour from Paris!",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF78350F),
                                fontFamily = FontFamily.Serif
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "I am virtually standing in front of the spectacular $activeLocationName! Did you know this masterpiece was designed to celebrate the centenary of the French Revolution? I blended my photo perfectly and the view is breathtaking. Can't wait to show you the blended pictures when I return!",
                                fontSize = 11.sp,
                                color = Color(0xFF78350F),
                                lineHeight = 16.sp,
                                fontFamily = FontFamily.Serif
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { showApiKeyWarning = false },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                            border = borderStroke(1.dp, Color(0xFF475569))
                        ) {
                            Text("Dismiss")
                        }

                        Button(
                            onClick = {
                                showApiKeyWarning = false
                                postcardContent = "Bonjour from the stunning $activeLocationName! I am standing in front of this gorgeous architectural marvel, blending in perfectly. The atmosphere is majestic, and I feel like a true global traveler. Wish you were here!"
                                showPostcardDialog = true
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFA855F7))
                        ) {
                            Text("Show Mock")
                        }
                    }
                }
            }
        }
    }
}

// Helper boundary stroke function
private fun borderStroke(width: androidx.compose.ui.unit.Dp, color: Color) = androidx.compose.foundation.BorderStroke(width, color)

// Premium white background removal algorithm with complete artifact elimination & halo removal
private fun removeWhiteBackground(src: Bitmap): Bitmap {
    val width = src.width
    val height = src.height
    val dest = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val pixels = IntArray(width * height)
    src.getPixels(pixels, 0, width, 0, 0, width, height)
    
    val isBackground = BooleanArray(width * height)
    val queue = java.util.ArrayDeque<Int>()
    
    // Inline helper to determine if a pixel belongs to white-ish background or studio white bleed
    fun isWhiteBg(pixelColor: Int): Boolean {
        val a = (pixelColor shr 24) and 0xFF
        if (a == 0) return true
        val r = (pixelColor shr 16) and 0xFF
        val g = (pixelColor shr 8) and 0xFF
        val b = pixelColor and 0xFF
        
        val minVal = minOf(r, g, b)
        val maxVal = maxOf(r, g, b)
        val diff = maxVal - minVal
        
        return minVal > 140 && diff < 60
    }
    
    // Add border pixels to start BFS
    for (x in 0 until width) {
        val idxTop = x
        if (isWhiteBg(pixels[idxTop])) {
            isBackground[idxTop] = true
            queue.add(idxTop)
        }
        val idxBottom = (height - 1) * width + x
        if (isWhiteBg(pixels[idxBottom])) {
            isBackground[idxBottom] = true
            queue.add(idxBottom)
        }
    }
    for (y in 1 until height - 1) {
        val idxLeft = y * width
        if (isWhiteBg(pixels[idxLeft])) {
            isBackground[idxLeft] = true
            queue.add(idxLeft)
        }
        val idxRight = y * width + (width - 1)
        if (isWhiteBg(pixels[idxRight])) {
            isBackground[idxRight] = true
            queue.add(idxRight)
        }
    }
    
    // Run BFS to mark connected white background
    val dx = intArrayOf(0, 0, -1, 1)
    val dy = intArrayOf(-1, 1, 0, 0)
    
    while (!queue.isEmpty()) {
        val curr = queue.poll() ?: break
        val cx = curr % width
        val cy = curr / width
        
        for (i in 0 until 4) {
            val nx = cx + dx[i]
            val ny = cy + dy[i]
            if (nx in 0 until width && ny in 0 until height) {
                val idx = ny * width + nx
                if (!isBackground[idx] && isWhiteBg(pixels[idx])) {
                    isBackground[idx] = true
                    queue.add(idx)
                }
            }
        }
    }
    
    // Global fallback pass: force clear any high-brightness background pixels regardless of BFS path
    for (i in pixels.indices) {
        val color = pixels[i]
        val a = (color shr 24) and 0xFF
        if (a == 0) {
            isBackground[i] = true
            continue
        }
        val r = (color shr 16) and 0xFF
        val g = (color shr 8) and 0xFF
        val b = color and 0xFF
        val minVal = minOf(r, g, b)
        val maxVal = maxOf(r, g, b)
        if (minVal > 210 && (maxVal - minVal) < 45) {
            isBackground[i] = true
        }
    }

    // Wipe background pixels completely to 100% transparent alpha (0x00000000)
    for (i in pixels.indices) {
        if (isBackground[i]) {
            pixels[i] = 0x00000000
        }
    }
    
    dest.setPixels(pixels, 0, width, 0, 0, width, height)
    return dest
}

data class AdaptedPhotoResult(
    val bitmap: Bitmap,
    val suggestedXOffset: Float
)

/**
 * Automatically adapts user pose, tilt angle, position, and bounding size for any photo style.
 * 1. Perspective & Angle Matching: Detects tilt and posture orientation, applying 3D/2D rotation & perspective matrix.
 * 2. Smart Bounding Anchor: Finds subject bounding box, crops tight, preserves natural Left/Right/Center intent.
 * 3. Auto-Scale Restoration: Restores golden ratio size relative to background canvas with zero bounding box padding.
 */
fun adaptUserPhotoPoseAndPosition(source: Bitmap): AdaptedPhotoResult {
    try {
        val width = source.width
        val height = source.height
        val pixels = IntArray(width * height)
        source.getPixels(pixels, 0, width, 0, 0, width, height)

        var minX = width
        var maxX = -1
        var minY = height
        var maxY = -1

        var topSumX = 0L
        var topCount = 0L
        var bottomSumX = 0L
        var bottomCount = 0L

        for (y in 0 until height) {
            for (x in 0 until width) {
                val color = pixels[y * width + x]
                val alpha = (color shr 24) and 0xFF
                if (alpha > 30) {
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y

                    if (y < height * 0.35) {
                        topSumX += x
                        topCount++
                    } else if (y > height * 0.65) {
                        bottomSumX += x
                        bottomCount++
                    }
                }
            }
        }

        if (minX >= maxX || minY >= maxY) {
            return AdaptedPhotoResult(source, 0f)
        }

        val sourceCenterX = (minX + maxX) / 2f
        val sourceCenterY = (minY + maxY) / 2f

        // Detect natural horizontal bias in original photo composition
        val horizontalBias = (sourceCenterX - width / 2f) / (width / 2f)
        val suggestedXOffset = when {
            horizontalBias < -0.18f -> -110f // Naturally cropped/aligned on left quadrant
            horizontalBias > 0.18f -> 110f   // Naturally cropped/aligned on right quadrant
            else -> 0f                       // Center
        }

        // 1. Perspective & Angle Matching
        val topCenterX = if (topCount > 0) topSumX.toFloat() / topCount else sourceCenterX
        val bottomCenterX = if (bottomCount > 0) bottomSumX.toFloat() / bottomCount else sourceCenterX
        val dx = topCenterX - bottomCenterX
        val dy = (height * 0.5f).coerceAtLeast(10f)

        var tiltDegrees = Math.toDegrees(kotlin.math.atan2(dx.toDouble(), dy.toDouble())).toFloat()
        tiltDegrees = tiltDegrees.coerceIn(-25f, 25f)

        val matrix = Matrix()

        if (kotlin.math.abs(tiltDegrees) > 0.5f) {
            matrix.postRotate(-tiltDegrees, sourceCenterX, sourceCenterY)
        }

        // Horizontal asymmetry skewing for left/right camera angles
        val skewX = (-horizontalBias * 0.05f).coerceIn(-0.08f, 0.08f)
        if (kotlin.math.abs(skewX) > 0.01f) {
            matrix.postSkew(skewX, 0f, sourceCenterX, sourceCenterY)
        }

        val transformed = Bitmap.createBitmap(source, 0, 0, width, height, matrix, true)

        // 2. Smart Bounding Anchor & Tight Subject Crop
        val tW = transformed.width
        val tH = transformed.height
        val tPixels = IntArray(tW * tH)
        transformed.getPixels(tPixels, 0, tW, 0, 0, tW, tH)

        var tMinX = tW
        var tMaxX = -1
        var tMinY = tH
        var tMaxY = -1

        for (y in 0 until tH) {
            for (x in 0 until tW) {
                val alpha = (tPixels[y * tW + x] shr 24) and 0xFF
                if (alpha > 30) {
                    if (x < tMinX) tMinX = x
                    if (x > tMaxX) tMaxX = x
                    if (y < tMinY) tMinY = y
                    if (y > tMaxY) tMaxY = y
                }
            }
        }

        if (tMinX >= tMaxX || tMinY >= tMaxY) {
            return AdaptedPhotoResult(transformed, suggestedXOffset)
        }

        val cropW = tMaxX - tMinX + 1
        val cropH = tMaxY - tMinY + 1

        val croppedSubject = Bitmap.createBitmap(transformed, tMinX, tMinY, cropW, cropH)

        // 3. Auto-Scale Restoration to target height (330px base)
        val targetSubjectH = 330
        val scaleRatio = targetSubjectH.toFloat() / cropH.toFloat()
        val finalSubjectW = (cropW * scaleRatio).toInt().coerceAtLeast(1)
        val finalSubjectH = (cropH * scaleRatio).toInt().coerceAtLeast(1)

        val scaledSubject = Bitmap.createScaledBitmap(croppedSubject, finalSubjectW, finalSubjectH, true)

        // Return tightly cropped subject bitmap directly to prevent box artifacts
        return AdaptedPhotoResult(scaledSubject, suggestedXOffset)
    } catch (e: Exception) {
        e.printStackTrace()
        return AdaptedPhotoResult(source, 0f)
    }
}
